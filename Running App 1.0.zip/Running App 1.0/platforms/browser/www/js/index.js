var firstLoop = 0;
var lat1, lat2, long1, long2;  //MAKE NOT GLOBAL VARIABLES?!?!?!?
var totalDistance;
var totalMetres;
var countSeconds = 00;
var countMinutes = 0;
var myVar;
var tM;
var tS;
var mpsAverageTarget;
var mpsAverageCurrent;
var timeTargetInSeconds;
var fastRange;
var vfastRange;
var slowRange;
var vocalToggle = 1;
var tuneChoice = 1;
var raceStage;
var startTime;
var currentTime;

var tick = 0;

var voice = document.getElementById("voice");


var music = document.getElementById('tune');
music.setAttribute('src','test-audio.mp3');
music.playbackRate = 1;

 alert("updated!");

function updateButtonFunction() { // Maybe change this to validate??
	

	 tM = document.getElementById("targetMin").value; //FUTURE Ollie
     tS = document.getElementById("targetSec").value; //FUTURE Ollie
	 
	 //USER TARGET VALIDATION!
	
	if(tS > 59 || tS < 0 ){
		alert("Please enter a suitable amount of Seconds!");
	}
	else if(tM > 59){
		alert("Please enter a suitable amount of Minutes!");
	}
	else if((isNaN(tM) == true) || (isNaN(tS) == true)){
		alert("Please enter in Numbers!");
	}
	else if(tM < 12){
		alert("Not going to happen Usain!");
	}
	else{
		
		if (firstLoop == 0) {
		startTime = Date.now();	
		document.getElementById("time").innerHTML = countMinutes + "0:00";    //Change name of test variable
		 watchID = navigator.geolocation.watchPosition(success, error, options);
		 firstLoop = 1;
		 tick = 0;
		 music.play();
		 
		 if (vocalToggle == 1){
			 music.volume = 0.2;
		 voice.setAttribute('src','intro_speech.mp3');
		 voice.play();
		 voice.onended = function() {
			 music.volume = 1;
			 voice.pause();
			 voice.currentTime = 0;
		 }; 
		 }
		 
		 
		 totalDistance = 0;
		 intervalFunction();   
		 timeConvertFuntion();
		 assignPacingVariables();
		 // upudateFuNtionnnnfdbaskdjhasd
		 document.getElementById("updateButton").innerHTML = "Stop Run!";
	}
	else {
		navigator.geolocation.clearWatch(watchID);
		firstLoop = 0;
		voice.pause();
		voice.currentTime = 0;
		music.pause();
		music.currentTime = 0;
		document.getElementById("updateButton").innerHTML = "Start Run!";
		alert("Please screenshot this and send it to Oliver! \n \n" + "Distance = " + totalMetres + "\n Tick Count = " + tick + "\n Time = " + countMinutes + ":" + countSeconds
		 + "\n Target = " + mpsAverageTarget + "\n Actual = " + mpsAverageCurrent);
		clearInterval(myVar);
		countSeconds = 0;
		countMinutes = 0;
		
		
	
	}
	}
	
	
	
	
}


	 
	function calculateDistance() {
	
  var R = 6371; // km
  var dLat = (lat2 - lat1).toRad(); //"d" refers to difference
  var dLon = (long2 - long1).toRad(); 
  var a = Math.sin(dLat / 2) * Math.sin(dLat / 2) +
          Math.cos(lat1.toRad()) * Math.cos(lat2.toRad()) * 
          Math.sin(dLon / 2) * Math.sin(dLon / 2); 
  var c = 2 * Math.atan2(Math.sqrt(a), Math.sqrt(1 - a)); 
  var d = R * c;
  d = d * 1000;
  d = Math.round(d);
  d = d / 1000;
  return d;
}
Number.prototype.toRad = function() {
  return this * Math.PI / 180;
}
	


var options = {
  enableHighAccuracy: true,
  timeout: 2000,
  maximumAge: 5000
};

function success(position) {   //Upon Location Update... 


  var temp; //temporary variable to solve rounding bug.
  var crd = position.coords;
  lat2 = lat1;       //Old latitude becomes lat2
  long2 = long1;                  //Old longitude becomes long2
  lat1 = crd.latitude;     // Current latitude 
  long1 = crd.longitude;
  var acc = Math.round(crd.accuracy);
  
  totalDistance = totalDistance + calculateDistance();
  
  totalMetres = totalDistance * 1000;
  
  totalMetres = Math.round(totalMetres);
  
  
  
  document.getElementById("distance").innerHTML = totalMetres + "m"; 
  
  
  tick++;

}

function error(err) {
  console.warn('ERROR(${err.code}): ${err.message}');
}


var input = 25;    //converted from minutes/seconds to seconds

var now = new Date(0);

function intervalFunction(){
	
myVar = setInterval(function(){
	
	
	currentTime = ((Date.now() - startTime) / 1000);  //Difference in ms between start and current time
	
	currentTime = Math.round(currentTime);
	
	
	countMinutes = (currentTime / 60);   // Find amount of minutes
	
	countMinutes = Math.floor(countMinutes); // Round down so that only minutes are included in figure
	
	
	//Get seconds
	
	countSeconds = currentTime - (countMinutes * 60);
	
	
	
	
	var countString = String(countSeconds);
	
	if (countString.length == 1){
		document.getElementById("time").innerHTML = countMinutes + ":" + "0" + countSeconds;
	} 
	else {
		document.getElementById("time").innerHTML = countMinutes + ":" + countSeconds;
	}
	
	
	if ((countSeconds == 10)||(countSeconds == 40)){ //for test sake -   10 and 40 update
	//speed check and tempo shift
	assignPacingVariables();
	getAverageSpeed();
	updateTempo();
	} //Average speed check and time shift every 30 seconds 
	

	},100); //accurate to a tenth of a second
}





function assignPacingVariables() {
	
	/*
	Four variables are used to depict at what m/s values the runner is slow or fast etc. 
	Anything above "vfastRange" is very fast.
	Between "fastRange" and "vfastRange" is fast.
	Between "mpsAverageTarget" and "fastRange" is perfect. 
	Between "slowRange" and "mpsAverageTarget" is slow.
	Anything below "slowRange" 
	*/
	
	
	
	var stageCalc = (timeTargetInSeconds / 5);        //(Stage based bounds.)
	
	if (currentTime < stageCalc){
		earlyRace();
	} 
	else if ((currentTime > stageCalc) && (currentTime < (stageCalc * 4)))
	{
		midRace();
	}
	else {
		lateRace();
	}
	
	

	
	
	
}

function earlyRace(){
	raceStage = 1;
	
	var pHolder; 	//Place Holder variable used for calculations
	
	//Get an m/s value for "vfastRange" 
	
	pHolder = (timeTargetInSeconds + 360);
	vfastRange = (5000 / pHolder); // Get unrounded Average Target in m/s
	vfastRange = vfastRange * 100;  // Multiply by 100 to round to 2 decimal places
	vfastRange = Math.round(vfastRange); 
	vfastRange = vfastRange / 100;    // Return to correct figure (now fully rounded)
	//Get an m/s value for "fastRange" 
	
	pHolder = (timeTargetInSeconds + 120);
	fastRange = (5000 / pHolder); // Get unrounded Average Target in m/s
	fastRange = fastRange * 100;  // Multiply by 100 to round to 2 decimal places
	fastRange = Math.round(fastRange); 
	fastRange = fastRange / 100;    // Return to correct figure (now fully rounded)
	
	//Get an m/s value for "slowRange" 
	
	pHolder = (timeTargetInSeconds - 360);
	slowRange = (5000 / pHolder); // Get unrounded Average Target in m/s
	slowRange = slowRange * 100;  // Multiply by 100 to round to 2 decimal places
	slowRange = Math.round(slowRange); 
	slowRange = slowRange / 100;    // Return to correct figure (now fully rounded)
	
}



function midRace(){
	raceStage = 2;
	
	var pHolder; 	//Place Holder variable used for calculations
	
	//Get an m/s value for "vfastRange" 
	
	pHolder = (timeTargetInSeconds + 120);
	vfastRange = (5000 / pHolder); // Get unrounded Average Target in m/s
	vfastRange = vfastRange * 100;  // Multiply by 100 to round to 2 decimal places
	vfastRange = Math.round(vfastRange); 
	vfastRange = vfastRange / 100;    // Return to correct figure (now fully rounded)
	
	//Get an m/s value for "fastRange" 
	
	pHolder = (timeTargetInSeconds + 60);
	fastRange = (5000 / pHolder); // Get unrounded Average Target in m/s
	fastRange = fastRange * 100;  // Multiply by 100 to round to 2 decimal places
	fastRange = Math.round(fastRange); 
	fastRange = fastRange / 100;    // Return to correct figure (now fully rounded)
	
	//Get an m/s value for "slowRange" 
	
	pHolder = (timeTargetInSeconds - 120);
	slowRange = (5000 / pHolder); // Get unrounded Average Target in m/s
	slowRange = slowRange * 100;  // Multiply by 100 to round to 2 decimal places
	slowRange = Math.round(slowRange); 
	slowRange = slowRange / 100;    // Return to correct figure (now fully rounded)
	
}

function lateRace(){
	raceStage = 3;
	
	var pHolder; 	//Place Holder variable used for calculations
	
	//Get an m/s value for "vfastRange" 
	
	pHolder = (timeTargetInSeconds + 70);
	vfastRange = (5000 / pHolder); // Get unrounded Average Target in m/s
	vfastRange = vfastRange * 100;  // Multiply by 100 to round to 2 decimal places
	vfastRange = Math.round(vfastRange); 
	vfastRange = vfastRange / 100;    // Return to correct figure (now fully rounded)
	
	//Get an m/s value for "fastRange" 
	
	pHolder = (timeTargetInSeconds + 20);
	fastRange = (5000 / pHolder); // Get unrounded Average Target in m/s
	fastRange = fastRange * 100;  // Multiply by 100 to round to 2 decimal places
	fastRange = Math.round(fastRange); 
	fastRange = fastRange / 100;    // Return to correct figure (now fully rounded)
	
	//Get an m/s value for "slowRange" 
	
	pHolder = (timeTargetInSeconds - 70);
	slowRange = (5000 / pHolder); // Get unrounded Average Target in m/s
	slowRange = slowRange * 100;  // Multiply by 100 to round to 2 decimal places
	slowRange = Math.round(slowRange); 
	slowRange = slowRange / 100;    // Return to correct figure (now fully rounded)
	
}





function timeConvertFuntion(){
	
	tS = parseInt(tS);
	
	timeTargetInSeconds = ((tM * 60) + tS);
	
	mpsAverageTarget = (5000 / timeTargetInSeconds); // Get unrounded Average Target in m/s
	mpsAverageTarget = mpsAverageTarget * 100;  // Multiply by 100 to round to 2 decimal places
	mpsAverageTarget = Math.round(mpsAverageTarget); 
	mpsAverageTarget = mpsAverageTarget / 100;    // Return to correct figure (now fully rounded)
	
}


function getAverageSpeed(){ // Get current m/s value
	
	totalMetres = totalDistance * 1000;
     mpsAverageCurrent = (totalMetres / ((countMinutes * 60) + countSeconds));      
}



function updateTempo() {
     // check current tempo against the various speed ranges.
	
	var a = (countMinutes * 60) + countSeconds; // temporary variable for comparison operators.
	
	//Display based changes included
	
    if( a < 60){
		music.playbackRate = 1;
		
		document.getElementById("temPace").style.borderColor = "lime";
		document.getElementById("status").innerHTML = "OnTrack";
		
	} 
	
	else if (mpsAverageCurrent < slowRange) {
		music.playbackRate = 1.2; //Very Slow Running (Tempo sped up significantly)
		document.getElementById("temPace").style.borderColor = "red";
		document.getElementById("status").innerHTML = "BehindTarget";
		document.getElementById("status").style.color = "red";
		
		
		if (vocalToggle == 1){
			music.volume = 0.2;
		voice.setAttribute('src','speed_up.mp3');
		voice.play();
		 voice.onended = function() {
			 music.volume = 1;
			 voice.pause();
			 voice.currentTime = 0;
		 };
		}
		
	}
	
	else if ((mpsAverageCurrent >= slowRange) && (mpsAverageCurrent < mpsAverageTarget)) {
		music.playbackRate = 1.1; //Slow Running (Tempo sped up slightly)
		
		document.getElementById("temPace").style.borderColor = "orange";
		document.getElementById("status").innerHTML = "BehindTarget";
		document.getElementById("status").style.color = "orange";
		
		if (vocalToggle == 1){
		music.volume = 0.2;
		voice.setAttribute('src','speed_up_slightly.mp3');
		voice.play();
		 voice.onended = function() {
			 music.volume = 1;
			 voice.pause();
			 voice.currentTime = 0;
		 };
		}
	}
	
	else if ((mpsAverageCurrent >= mpsAverageTarget) && (mpsAverageCurrent < fastRange)) {
		music.playbackRate = 1.0; //Perfect Running (Tempo at standard)
		
		document.getElementById("temPace").style.borderColor = "lime";
		document.getElementById("status").innerHTML = "OnTrack";
		document.getElementById("status").style.color = "lime";
		
		if (vocalToggle == 1){
		music.volume = 0.2;
		voice.setAttribute('src','perfect_pace.mp3');
		voice.play();
		 voice.onended = function() {
			 music.volume = 1;
			 voice.pause();
			 voice.currentTime = 0;
		 };
		}
	}
	
	
	
	else if ((mpsAverageCurrent >= fastRange) && (mpsAverageCurrent < vfastRange)) {
		music.playbackRate = 0.9; //Fast Running (Tempo slowed down slightly)
		
		document.getElementById("temPace").style.borderColor = "blue";
		document.getElementById("status").innerHTML = "AheadOfTarget";
		document.getElementById("status").style.color = "blue";
		
		if (vocalToggle == 1){
		music.volume = 0.2;
		voice.setAttribute('src','slow_down_slightly.mp3');
		voice.play();
		 voice.onended = function() {
			 music.volume = 1;
			 voice.pause();
			 voice.currentTime = 0;
		 };
		}
	}
	else { 
	
		music.playbackRate = 0.8; //Very Fast Running (Tempo slowed down significantly)
		
		document.getElementById("temPace").style.borderColor = "mediumpurple";
		document.getElementById("status").innerHTML = "AheadOfTarget";
		document.getElementById("status").style.color = "mediumpurplet";
		
		if (vocalToggle == 1){
		music.volume = 0.2;
		voice.setAttribute('src','slow_down.mp3');
		voice.play();
		 voice.onended = function() {
			 music.volume = 1;
			 voice.pause();
			 voice.currentTime = 0;
		 };
		}
		
	}

}


function toggleFunction(){
	if (vocalToggle == 1){ //Turning the vocal guide off.
		vocalToggle = 0;
		document.getElementById("voiceToggle").style.borderColor = "grey"
	}
	else {         //Turning the vocal guide on.
		vocalToggle = 1;
		document.getElementById("voiceToggle").style.borderColor = "yellow"
	}
}



function musicFunctionA(){
	
	if (firstLoop == 0){
	tuneChoice = 1;
	music.setAttribute('src','test-audio.mp3');
	document.getElementById("musicA").style.borderColor = "yellow";
	document.getElementById("musicB").style.borderColor = "grey";
	}
	
}

function musicFunctionB(){
	if (firstLoop == 0){
	tuneChoice = 2;
	music.setAttribute('src','test-audio.mp3');
	document.getElementById("musicA").style.borderColor = "grey";
	document.getElementById("musicB").style.borderColor = "yellow";
	}
}





var app = {
    // Application Constructor
    initialize: function() {
        this.bindEvents();
    },
    // Bind Event Listeners
    //
    // Bind any events that are required on startup. Common events are:
    // 'load', 'deviceready', 'offline', and 'online'.
    bindEvents: function() {
        document.addEventListener('deviceready', this.onDeviceReady, false);
    },
    // deviceready Event Handler
    //
    // The scope of 'this' is the event. In order to call the 'receivedEvent'
    // function, we must explicitly call 'app.receivedEvent(...);'
    onDeviceReady: function() {
        app.receivedEvent('deviceready');
    },
    // Update DOM on a Received Event
    receivedEvent: function(id) {
        var parentElement = document.getElementById(id);
        var listeningElement = parentElement.querySelector('.listening');
        var receivedElement = parentElement.querySelector('.received');

        listeningElement.setAttribute('style', 'display:none;');
        receivedElement.setAttribute('style', 'display:block;');

        console.log('Received Event: ' + id);
    }
};

